
1) 安装依赖:  py -m pip install -r requirements.txt
2) 复制 .env.example 为 .env 并填 FACEIT_API_KEY
3) 双击 start_tracker.bat 一键同步+启动+打开网页
